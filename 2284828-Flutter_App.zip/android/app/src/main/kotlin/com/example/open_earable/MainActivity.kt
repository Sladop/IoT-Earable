package edu.kit.teco.openEarable

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
